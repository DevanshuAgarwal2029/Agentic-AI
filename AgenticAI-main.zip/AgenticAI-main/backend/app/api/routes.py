"""
API Routes for fraud detection system.
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from pydantic import BaseModel

from app.db.database import get_db
from app.services.data_service import DataService, load_sample_data
from app.services.ml_service import ml_service
from app.models.transaction import Transaction
from app.schemas.transaction import (
    TransactionResponse,
    TransactionCreate,
    TransactionPredictRequest,
    TransactionPredictResponse,
    TransactionListResponse,
)

router = APIRouter()


@router.get("/transactions", response_model=TransactionListResponse)
def get_transactions(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    transaction_type: Optional[str] = None,
    is_fraud: Optional[bool] = None,
    db: Session = Depends(get_db),
):
    """
    Get list of transactions with optional filtering.

    - **skip**: Number of records to skip
    - **limit**: Maximum number of records (max 1000)
    - **transaction_type**: Filter by transaction type (optional)
    - **is_fraud**: Filter by fraud status (optional)
    """
    data_service = DataService(db)
    transactions = data_service.get_transactions(
        skip=skip,
        limit=limit,
        transaction_type=transaction_type,
        is_fraud=is_fraud,
    )
    total = data_service.get_transaction_count()

    return TransactionListResponse(
        transactions=transactions,
        total=total,
    )


@router.get("/transaction/{transaction_id}", response_model=TransactionResponse)
def get_transaction(transaction_id: int, db: Session = Depends(get_db)):
    """
    Get a single transaction by ID.

    - **transaction_id**: The ID of the transaction to retrieve
    """
    data_service = DataService(db)
    transaction = data_service.get_transaction_by_id(transaction_id)

    if not transaction:
        raise HTTPException(status_code=404, detail="Transaction not found")

    return transaction


@router.post("/predict", response_model=TransactionPredictResponse)
def predict_fraud(request: TransactionPredictRequest):
    """
    Predict fraud risk for a transaction.

    Accepts transaction details and returns:
    - **risk_score**: Probability of fraud (0-1)
    - **prediction**: 0 = legitimate, 1 = fraud
    - **is_high_risk**: True if risk_score > 0.5
    """
    ml_svc = ml_service

    try:
        result = ml_svc.predict(
            step=request.step,
            transaction_type=request.type,
            amount=request.amount,
            oldbalanceOrg=request.oldbalanceOrg,
            newbalanceOrig=request.newbalanceOrig,
            oldbalanceDest=request.oldbalanceDest,
            newbalanceDest=request.newbalanceDest,
        )

        return TransactionPredictResponse(
            risk_score=result["risk_score"],
            prediction=result["prediction"],
            is_high_risk=result["is_high_risk"],
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")


@router.post("/load-data")
def load_data(
    limit: int = Query(1000, ge=1, le=10000),
    db: Session = Depends(get_db),
):
    """
    Load sample data from PaySim dataset into database.

    - **limit**: Maximum number of records to load (default 1000)
    """
    import os

    # Find the paysim.csv file
    possible_paths = [
        os.path.join(os.path.dirname(__file__), "..", "..", "..", "paysim.csv"),
        os.path.join(os.path.dirname(__file__), "..", "..", "paysim.csv"),
        "/Users/vanshyadav/Desktop/AgenticAI/paysim.csv",
    ]

    filepath = None
    for path in possible_paths:
        if os.path.exists(path):
            filepath = path
            break

    if not filepath:
        raise HTTPException(
            status_code=404,
            detail="paysim.csv not found. Please ensure dataset is available."
        )

    try:
        count = load_sample_data(db, filepath, limit=limit)
        return {
            "message": f"Successfully loaded {count} transactions",
            "count": count,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to load data: {str(e)}")


@router.get("/stats")
def get_stats(db: Session = Depends(get_db)):
    """
    Get dashboard statistics.
    """
    data_service = DataService(db)
    total = data_service.get_transaction_count()

    # Get fraud count
    fraud_txns = data_service.get_transactions(is_fraud=True, limit=10000)
    fraud_count = len(fraud_txns)

    # Get recent transactions
    recent = data_service.get_transactions(limit=10)

    return {
        "total_transactions": total,
        "fraud_detected": fraud_count,
        "fraud_rate": round(fraud_count / total * 100, 2) if total > 0 else 0,
        "recent_transactions": recent[:5],
    }


@router.get("/health")
def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "model_loaded": ml_service._model is not None,
    }

@router.get("/model-performance")
def get_model_performance():
    """
    Get model performance metrics.
    """
    # Mock metrics - replace with real calculations if you have test data
    metrics = {
        "accuracy": 0.95,
        "precision": 0.92,
        "recall": 0.88,
        "f1_score": 0.90,
    }
    return metrics