"""
ML Service for fraud detection predictions.
Handles model loading and inference.
"""

import joblib
import os
from typing import Dict, Any, Optional
import numpy as np

# Paths
MODEL_DIR = os.path.join(os.path.dirname(__file__), "..", "models")
MODEL_PATH = os.path.join(MODEL_DIR, "fraud_model.pkl")
ENCODER_PATH = os.path.join(MODEL_DIR, "type_encoder.pkl")


class MLService:
    """Service for fraud detection ML predictions."""

    _instance: Optional["MLService"] = None
    _model = None
    _type_encoder = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def load_model(self) -> None:
        """Load the trained model and encoder."""
        if self._model is None:
            print(f"Loading model from: {MODEL_PATH}")
            self._model = joblib.load(MODEL_PATH)

        if self._type_encoder is None:
            print(f"Loading type encoder from: {ENCODER_PATH}")
            self._type_encoder = joblib.load(ENCODER_PATH)

        print("Model loaded successfully!")

    def _encode_type(self, transaction_type: str) -> int:
        """Encode transaction type using the saved encoder."""
        if self._type_encoder is None:
            self.load_model()

        return self._type_encoder.get(transaction_type, -1)

    def predict(
        self,
        step: int,
        transaction_type: str,
        amount: float,
        oldbalanceOrg: float,
        newbalanceOrig: float,
        oldbalanceDest: float,
        newbalanceDest: float,
    ) -> Dict[str, Any]:
        """
        Predict fraud risk for a transaction.

        Args:
            step: Time step in hours
            transaction_type: Type of transaction (CASH_OUT, TRANSFER, etc.)
            amount: Transaction amount
            oldbalanceOrg: Sender's balance before transaction
            newbalanceOrig: Sender's balance after transaction
            oldbalanceDest: Receiver's balance before transaction
            newbalanceDest: Receiver's balance after transaction

        Returns:
            Dict with risk_score, prediction, and is_high_risk
        """
        if self._model is None:
            self.load_model()

        # Encode type
        type_encoded = self._encode_type(transaction_type)

        # Create feature vector (order must match training)
        features = np.array([[
            type_encoded,
            amount,
            oldbalanceOrg,
            newbalanceOrig,
            oldbalanceDest,
            newbalanceDest,
        ]])

        # Predict
        prediction = self._model.predict(features)[0]
        probability = self._model.predict_proba(features)[0][1]

        return {
            "risk_score": float(probability),
            "prediction": int(prediction),
            "is_high_risk": probability > 0.5,
            "transaction_type_encoded": type_encoded,
        }

    def predict_batch(
        self,
        transactions: list[Dict[str, Any]],
    ) -> list[Dict[str, Any]]:
        """
        Predict fraud risk for multiple transactions.

        Args:
            transactions: List of transaction dictionaries

        Returns:
            List of prediction results
        """
        if self._model is None:
            self.load_model()

        results = []

        for txn in transactions:
            result = self.predict(
                step=txn.get("step", 0),
                transaction_type=txn.get("type", "UNKNOWN"),
                amount=txn.get("amount", 0),
                oldbalanceOrg=txn.get("oldbalanceOrg", 0),
                newbalanceOrig=txn.get("newbalanceOrig", 0),
                oldbalanceDest=txn.get("oldbalanceDest", 0),
                newbalanceDest=txn.get("newbalanceDest", 0),
            )
            results.append(result)

        return results


# Singleton instance
ml_service = MLService()
