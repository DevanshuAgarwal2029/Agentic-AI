"""
Data Service for database operations.
Handles transaction data loading and querying.
"""

from typing import List, Optional
from sqlalchemy.orm import Session
from app.models.transaction import Transaction


class DataService:
    """Service for database operations."""

    def __init__(self, db: Session):
        self.db = db

    def get_transactions(
        self,
        skip: int = 0,
        limit: int = 100,
        transaction_type: Optional[str] = None,
        is_fraud: Optional[bool] = None,
    ) -> List[Transaction]:
        """
        Get transactions with optional filtering.

        Args:
            skip: Number of records to skip
            limit: Maximum number of records
            transaction_type: Filter by transaction type
            is_fraud: Filter by fraud status

        Returns:
            List of Transaction records
        """
        query = self.db.query(Transaction)

        if transaction_type:
            query = query.filter(Transaction.type == transaction_type)

        if is_fraud is not None:
            query = query.filter(Transaction.isFraud == is_fraud)

        return query.offset(skip).limit(limit).all()

    def get_transaction_by_id(self, transaction_id: int) -> Optional[Transaction]:
        """Get a single transaction by ID."""
        return self.db.query(Transaction).filter(
            Transaction.id == transaction_id
        ).first()

    def get_transaction_count(self) -> int:
        """Get total number of transactions."""
        return self.db.query(Transaction).count()

    def create_transaction(self, transaction_data: dict) -> Transaction:
        """
        Create a new transaction record.

        Args:
            transaction_data: Dictionary with transaction fields

        Returns:
            Created Transaction record
        """
        transaction = Transaction(**transaction_data)
        self.db.add(transaction)
        self.db.commit()
        self.db.refresh(transaction)
        return transaction

    def create_transactions_batch(self, transactions_data: List[dict]) -> List[Transaction]:
        """
        Create multiple transaction records.

        Args:
            transactions_data: List of transaction dictionaries

        Returns:
            List of created Transaction records
        """
        transactions = [Transaction(**data) for data in transactions_data]
        self.db.add_all(transactions)
        self.db.commit()
        return transactions

    def update_transaction_risk(
        self,
        transaction_id: int,
        risk_score: float,
        is_fraud: bool,
    ) -> Optional[Transaction]:
        """
        Update transaction with prediction results.

        Args:
            transaction_id: ID of transaction to update
            risk_score: Predicted risk score
            is_fraud: Predicted fraud status

        Returns:
            Updated Transaction record
        """
        transaction = self.get_transaction_by_id(transaction_id)
        if transaction:
            transaction.risk_score = risk_score
            transaction.isFraud = is_fraud
            self.db.commit()
            self.db.refresh(transaction)
        return transaction


def load_sample_data(db: Session, filepath: str, limit: int = 1000) -> int:
    """
    Load sample data from CSV into database.

    Args:
        db: Database session
        filepath: Path to CSV file
        limit: Maximum number of records to load

    Returns:
        Number of records loaded
    """
    import pandas as pd

    print(f"Loading data from: {filepath}")
    df = pd.read_csv(filepath, nrows=limit)

    transactions = []
    for _, row in df.iterrows():
        txn = Transaction(
            step=int(row["step"]),
            type=row["type"],
            amount=float(row["amount"]),
            oldbalanceOrg=float(row["oldbalanceOrg"]),
            newbalanceOrig=float(row["newbalanceOrig"]),
            oldbalanceDest=float(row["oldbalanceDest"]),
            newbalanceDest=float(row["newbalanceDest"]),
            isFraud=bool(row["isFraud"]),
        )
        transactions.append(txn)

    db.add_all(transactions)
    db.commit()

    print(f"Loaded {len(transactions)} transactions")
    return len(transactions)
