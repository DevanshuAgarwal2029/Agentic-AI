from sqlalchemy import Column, Integer, String, Float, Boolean, ForeignKey
from sqlalchemy.orm import relationship
from app.db.database import Base


class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(Integer, primary_key=True, index=True)
    step = Column(Integer, index=True)
    type = Column(String, index=True)
    amount = Column(Float)
    oldbalanceOrg = Column(Float)
    newbalanceOrig = Column(Float)
    oldbalanceDest = Column(Float)
    newbalanceDest = Column(Float)
    isFraud = Column(Boolean, default=False)
    risk_score = Column(Float)

    def __repr__(self):
        return f"<Transaction(id={self.id}, type={self.type}, amount={self.amount}, isFraud={self.isFraud})>"
