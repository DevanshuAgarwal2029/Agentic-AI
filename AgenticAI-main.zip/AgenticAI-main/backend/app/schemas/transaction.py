from pydantic import BaseModel, Field
from typing import Optional, List


class TransactionBase(BaseModel):
    step: int = Field(..., ge=0, description="Time step in hours")
    type: str = Field(..., description="Transaction type")
    amount: float = Field(..., gt=0, description="Transaction amount")
    oldbalanceOrg: float = Field(..., ge=0, description="Sender's balance before transaction")
    newbalanceOrig: float = Field(..., ge=0, description="Sender's balance after transaction")
    oldbalanceDest: float = Field(..., ge=0, description="Receiver's balance before transaction")
    newbalanceDest: float = Field(..., ge=0, description="Receiver's balance after transaction")


class TransactionCreate(TransactionBase):
    """Schema for creating a new transaction."""
    pass


class TransactionPredictRequest(BaseModel):
    """Schema for prediction request."""
    step: int
    type: str
    amount: float
    oldbalanceOrg: float
    newbalanceOrig: float
    oldbalanceDest: float
    newbalanceDest: float


class TransactionPredictResponse(BaseModel):
    """Schema for prediction response."""
    risk_score: float = Field(..., description="Fraud risk score between 0 and 1")
    prediction: int = Field(..., description="0 = legitimate, 1 = fraud")
    is_high_risk: bool = Field(..., description="True if risk_score > 0.5")


class TransactionResponse(TransactionBase):
    """Schema for transaction response with additional fields."""
    id: int
    isFraud: bool
    risk_score: Optional[float] = None

    class Config:
        from_attributes = True


class TransactionListResponse(BaseModel):
    """Schema for list of transactions."""
    transactions: List[TransactionResponse]
    total: int
