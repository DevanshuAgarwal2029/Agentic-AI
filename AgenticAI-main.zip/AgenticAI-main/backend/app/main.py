"""
FraudGuard AI - Backend API Server

Production-grade fraud detection API with ML predictions.
"""
from dotenv import load_dotenv
load_dotenv()
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.db.database import engine, Base
from app.api.routes import router
from app.ai.agent.routes import router as agent_router
from app.services.ml_service import ml_service

# Create database tables
Base.metadata.create_all(bind=engine)

# Initialize FastAPI app
app = FastAPI(
    title="FraudGuard AI API",
    description="Production-grade fraud detection API with ML predictions",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# Configure CORS for frontend integration
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:3001",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:3001",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load ML model on startup
@app.on_event("startup")
async def startup_event():
    """Load ML model when server starts."""
    print("Starting FraudGuard AI API...")
    ml_service.load_model()
    print("FraudGuard AI API ready!")

# Include API routes
app.include_router(router, prefix="/api")
app.include_router(agent_router, prefix="/api/agent")


@app.get("/")
def root():
    """Root endpoint with API info."""
    return {
        "name": "FraudGuard AI API",
        "version": "1.0.0",
        "description": "AI-powered fraud detection system",
        "docs": "/docs",
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
