"""
Embedding service for RAG system.
Handles text embedding generation and FAISS index management.
"""

import os
import numpy as np
from typing import List, Tuple
import faiss
from sentence_transformers import SentenceTransformer

from app.ai.rag.knowledge_base import get_all_knowledge_text, KNOWLEDGE_BASE

# Configuration
MODEL_NAME = "all-MiniLM-L6-v2"
INDEX_PATH = os.path.join(os.path.dirname(__file__), "faiss_index.bin")


class EmbeddingService:
    """Service for generating and managing embeddings."""

    _instance = None
    _model = None
    _index = None
    _knowledge_texts = None
    _dimension = 384  # Dimension for all-MiniLM-L6-v2

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def load_model(self) -> None:
        """Load the sentence transformer model."""
        if self._model is None:
            print(f"Loading embedding model: {MODEL_NAME}")
            self._model = SentenceTransformer(MODEL_NAME)
            self._dimension = self._model.get_sentence_embedding_dimension()
            print(f"Model loaded. Embedding dimension: {self._dimension}")

    def load_or_create_index(self) -> None:
        """Load existing FAISS index or create a new one."""
        self.load_model()

        if os.path.exists(INDEX_PATH):
            print(f"Loading existing FAISS index from: {INDEX_PATH}")
            self._index = faiss.read_index(INDEX_PATH)
            self._knowledge_texts = get_all_knowledge_text()
        else:
            print("Creating new FAISS index...")
            self._create_index()

    def _create_index(self) -> None:
        """Create a new FAISS index with knowledge base embeddings."""
        self._knowledge_texts = get_all_knowledge_text()

        if not self._knowledge_texts:
            raise ValueError("Knowledge base is empty")

        # Generate embeddings
        print(f"Generating embeddings for {len(self._knowledge_texts)} knowledge entries...")
        embeddings = self._model.encode(
            self._knowledge_texts,
            convert_to_numpy=True,
            show_progress_bar=True,
        )

        # Create FAISS index (using L2 distance)
        self._index = faiss.IndexFlatL2(self._dimension)
        self._index.add(embeddings.astype(np.float32))

        # Save index
        faiss.write_index(self._index, INDEX_PATH)
        print(f"FAISS index created and saved to: {INDEX_PATH}")

    def generate_embedding(self, text: str) -> np.ndarray:
        """Generate embedding for a single text."""
        if self._model is None:
            self.load_model()

        embedding = self._model.encode(text, convert_to_numpy=True)
        return embedding.astype(np.float32)

    def generate_embeddings(self, texts: List[str]) -> np.ndarray:
        """Generate embeddings for multiple texts."""
        if self._model is None:
            self.load_model()

        embeddings = self._model.encode(texts, convert_to_numpy=True)
        return embeddings.astype(np.float32)

    @property
    def index(self):
        """Get the FAISS index."""
        if self._index is None:
            self.load_or_create_index()
        return self._index

    @property
    def knowledge_texts(self) -> List[str]:
        """Get the knowledge texts."""
        if self._knowledge_texts is None:
            self.load_or_create_index()
        return self._knowledge_texts

    def rebuild_index(self) -> None:
        """Force rebuild of the FAISS index."""
        if os.path.exists(INDEX_PATH):
            os.remove(INDEX_PATH)
        self._index = None
        self._knowledge_texts = None
        self._create_index()


# Singleton instance
embedding_service = EmbeddingService()
