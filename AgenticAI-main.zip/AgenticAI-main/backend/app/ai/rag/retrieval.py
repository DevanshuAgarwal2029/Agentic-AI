"""
Retrieval service for RAG system.
Handles similarity search and context retrieval.
"""

from typing import List, Dict, Tuple
import numpy as np

from app.ai.rag.embedding import embedding_service
from app.ai.rag.knowledge_base import KNOWLEDGE_BASE


class RetrievalService:
    """Service for retrieving relevant knowledge."""

    def __init__(self, top_k: int = 3):
        """
        Initialize retrieval service.

        Args:
            top_k: Number of relevant documents to retrieve
        """
        self.top_k = top_k

    def retrieve(self, query: str) -> List[Dict[str, str]]:
        """
        Retrieve top-k relevant knowledge entries for a query.

        Args:
            query: The search query (transaction description)

        Returns:
            List of relevant knowledge entries with metadata
        """
        # Ensure index is loaded
        index = embedding_service.index
        knowledge_texts = embedding_service.knowledge_texts

        # Generate query embedding
        query_embedding = embedding_service.generate_embedding(query)
        query_embedding = query_embedding.reshape(1, -1)

        # Search FAISS index
        distances, indices = index.search(query_embedding.astype(np.float32), self.top_k)

        # Retrieve relevant knowledge
        results = []
        for i, idx in enumerate(indices[0]):
            if idx < len(knowledge_texts):
                # Find corresponding knowledge entry
                for kb in KNOWLEDGE_BASE:
                    if kb["content"] == knowledge_texts[idx]:
                        results.append({
                            "id": kb["id"],
                            "content": kb["content"],
                            "category": kb["category"],
                            "relevance_score": float(1 / (1 + distances[0][i])),
                        })
                        break

        return results

    def retrieve_with_scores(
        self,
        query: str,
        min_score: float = 0.5,
    ) -> List[Dict[str, str]]:
        """
        Retrieve knowledge entries with minimum relevance score filter.

        Args:
            query: The search query
            min_score: Minimum relevance score threshold

        Returns:
            Filtered list of relevant knowledge
        """
        results = self.retrieve(query)
        return [r for r in results if r["relevance_score"] >= min_score]

    def format_context(self, results: List[Dict[str, str]]) -> str:
        """
        Format retrieved context for LLM prompt.

        Args:
            results: List of retrieved knowledge entries

        Returns:
            Formatted context string
        """
        if not results:
            return "No relevant knowledge found."

        formatted = []
        for i, result in enumerate(results, 1):
            formatted.append(
                f"[{i}] ({result['category']}) {result['content']} "
                f"(relevance: {result['relevance_score']:.2f})"
            )

        return "\n\n".join(formatted)


def create_transaction_query(
    transaction_type: str,
    amount: float,
    oldbalanceOrg: float,
    newbalanceOrig: float,
    risk_score: float,
) -> str:
    """
    Create a descriptive query from transaction data for RAG retrieval.

    Args:
        transaction_type: Type of transaction
        amount: Transaction amount
        oldbalanceOrg: Sender's balance before
        newbalanceOrig: Sender's balance after
        risk_score: ML-predicted risk score

    Returns:
        Query string for similarity search
    """
    balance_change = oldbalanceOrg - newbalanceOrig
    balance_ratio = newbalanceOrig / oldbalanceOrg if oldbalanceOrg > 0 else 0

    query_parts = [
        f"{transaction_type} transaction",
        f"amount ${amount:,.2f}",
    ]

    if risk_score > 0.7:
        query_parts.append("high fraud risk")

    if balance_ratio < 0.1 and amount > 1000:
        query_parts.append("account drained")

    if balance_change > 10000:
        query_parts.append("large balance change")

    return " ".join(query_parts)


# Singleton instance
retrieval_service = RetrievalService(top_k=3)
