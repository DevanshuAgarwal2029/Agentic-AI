"""
Knowledge Base for RAG system.
Contains fraud detection rules and patterns.
"""

from typing import List, Dict

# Fraud detection knowledge base
KNOWLEDGE_BASE: List[Dict[str, str]] = [
    {
        "id": "KB001",
        "content": "Large transactions (>$10,000) with low sender balance may indicate account takeover or money laundering.",
        "category": "amount_risk",
    },
    {
        "id": "KB002",
        "content": "TRANSFER and CASH_OUT transaction types have the highest fraud rates in electronic payments.",
        "category": "transaction_type",
    },
    {
        "id": "KB003",
        "content": "When oldbalanceOrg is significantly lower than the transaction amount, it suggests the account may be drained.",
        "category": "balance_pattern",
    },
    {
        "id": "KB004",
        "content": "Transactions where newbalanceOrig equals 0 after the transaction indicate complete fund drainage - a strong fraud indicator.",
        "category": "balance_pattern",
    },
    {
        "id": "KB005",
        "content": "Rapid sequential transactions in short time periods are suspicious and may indicate automated fraud attacks.",
        "category": "temporal_pattern",
    },
    {
        "id": "KB006",
        "content": "When oldbalanceDest is 0 and newbalanceDest remains 0 after a large transfer, funds may be moving through mule accounts.",
        "category": "destination_pattern",
    },
    {
        "id": "KB007",
        "content": "PAYMENT transactions generally have lower fraud risk compared to TRANSFER and CASH_OUT operations.",
        "category": "transaction_type",
    },
    {
        "id": "KB008",
        "content": "Transactions with risk scores above 0.7 should be flagged for manual review before processing.",
        "category": "risk_threshold",
    },
    {
        "id": "KB009",
        "content": "Transactions with risk scores above 0.9 should be automatically blocked to prevent potential fraud.",
        "category": "risk_threshold",
    },
    {
        "id": "KB010",
        "content": "A sudden change in transaction patterns (amount, frequency, destination) compared to historical behavior indicates potential account compromise.",
        "category": "behavioral_pattern",
    },
    {
        "id": "KB011",
        "content": "CASH_IN transactions followed immediately by CASH_OUT of similar amounts may indicate money laundering through layering.",
        "category": "pattern_sequence",
    },
    {
        "id": "KB012",
        "content": "Transactions occurring at unusual hours (2-5 AM) combined with high amounts warrant additional scrutiny.",
        "category": "temporal_pattern",
    },
    {
        "id": "KB013",
        "content": "When the difference between oldbalanceOrg and amount is minimal, leaving near-zero balance, this is a red flag for fraud.",
        "category": "balance_pattern",
    },
    {
        "id": "KB014",
        "content": "Multiple transactions to the same destination within a short period may indicate structured transactions to avoid detection thresholds.",
        "category": "pattern_sequence",
    },
    {
        "id": "KB015",
        "content": "DEBIT transactions typically have lower fraud risk as they are linked to verified card operations with PIN authentication.",
        "category": "transaction_type",
    },
]


def get_knowledge_by_category(category: str) -> List[Dict[str, str]]:
    """Retrieve knowledge entries by category."""
    return [kb for kb in KNOWLEDGE_BASE if kb["category"] == category]


def get_all_knowledge_text() -> List[str]:
    """Get all knowledge as text strings for embedding."""
    return [kb["content"] for kb in KNOWLEDGE_BASE]


def get_knowledge_by_id(kb_id: str) -> Dict[str, str]:
    """Retrieve a specific knowledge entry by ID."""
    for kb in KNOWLEDGE_BASE:
        if kb["id"] == kb_id:
            return kb
    return {}
