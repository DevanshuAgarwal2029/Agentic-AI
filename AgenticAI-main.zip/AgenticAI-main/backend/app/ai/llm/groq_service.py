"""
Groq LLM Service - Free fast inference for fraud detection.
"""
from groq import Groq
import os

class GroqService:
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv("GROQ_API_KEY")
        if not self.api_key:
            raise ValueError("GROQ_API_KEY not found in environment variables")
        self.client = Groq(api_key=self.api_key)
        # List of models in preference order (fallback if one is decommissioned)
        self.models = [
    "llama-3.1-70b-versatile",      # Primary choice - high quality
    "llama-3.1-8b-instant",         # Fallback - faster  
    "mixtral-8x7b-32768",           # Fallback - older but stable
    "deepseek-r1-distill-llama-70b" # Fallback - reasoning-focused
]
        self.model = self.models[0]  # Use first model by default
    
    def generate_fraud_response(self, query: str) -> dict:
        """
        Generate fraud detection guidance using Groq LLM.
        """
        system_prompt = """You are an expert financial fraud detection consultant with 20+ years of experience.

Provide detailed, actionable advice on:
- Fraud patterns and indicators (specific red flags)
- Transaction risk assessment (metrics and thresholds)
- Fraud prevention strategies (practical recommendations)
- Financial security best practices

Guidelines:
1. Be specific with numbers and percentages
2. Reference real fraud detection techniques
3. Structure your response with clear sections
4. Provide actionable recommendations
5. Keep responses focused on fraud and finance

Example: Instead of "watch for suspicious activity", say "Monitor transactions >150% of customer's 90-day average, or velocity >5 transactions in <10 minutes"."""
        
        # Try each model until one works
        for model in self.models:
            try:
                response = self.client.chat.completions.create(
                    model=model,
                    messages=[
                        {
                            "role": "system",
                            "content": system_prompt
                        },
                        {
                            "role": "user",
                            "content": query
                        }
                    ],
                    temperature=0.7,
                    max_tokens=1500,
                )
                
                # Update current model if successful
                self.model = model
                
                return {
                    "answer": response.choices[0].message.content,
                    "sources": [f"Groq {model.split('/')[0]}"],
                    "confidence": 0.92
                }
            except Exception as e:
                error_msg = str(e)
                # If model is decommissioned, try next one
                if "decommissioned" in error_msg or "not found" in error_msg:
                    print(f"Model {model} decommissioned, trying next...")
                    continue
                else:
                    # Other error, return it
                    print(f"Groq API Error: {error_msg}")
                    return {
                        "answer": f"Error: Unable to connect to AI service. {error_msg}",
                        "sources": [],
                        "confidence": 0.0
                    }
        
        # All models failed
        return {
            "answer": "Error: Unable to connect to AI service. All models are currently unavailable.",
            "sources": [],
            "confidence": 0.0
        }

# Initialize service
groq_service = GroqService()