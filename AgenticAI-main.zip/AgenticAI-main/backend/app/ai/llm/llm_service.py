"""
LLM Service for AI agent.
Handles LLM interactions for reasoning and explanation generation.
"""

import os
import json
from typing import Dict, Any, Optional
from openai import OpenAI

# Configuration
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
MODEL_NAME = "gpt-4o-mini"


class LLMService:
    """Service for LLM-based reasoning and response generation."""

    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize LLM service.

        Args:
            api_key: OpenAI API key (falls back to env var)
        """
        self.api_key = api_key or OPENAI_API_KEY
        self.client = None
        self._use_mock = False

        if self.api_key:
            self.client = OpenAI(api_key=self.api_key)
        else:
            print("Warning: OPENAI_API_KEY not set. Using mock responses.")
            self._use_mock = True

    def generate_response(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.3,
        max_tokens: int = 500,
    ) -> Dict[str, Any]:
        """
        Generate a response from the LLM.

        Args:
            prompt: User prompt
            system_prompt: System instruction
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate

        Returns:
            Parsed JSON response
        """
        if self._use_mock or self.client is None:
            return self._mock_response(prompt)

        try:
            response = self.client.chat.completions.create(
                model=MODEL_NAME,
                messages=[
                    {"role": "system", "content": system_prompt or self._default_system_prompt()},
                    {"role": "user", "content": prompt},
                ],
                temperature=temperature,
                max_tokens=max_tokens,
                response_format={"type": "json_object"},
            )

            content = response.choices[0].message.content
            return json.loads(content)

        except Exception as e:
            print(f"LLM error: {e}")
            return self._mock_response(prompt)

    def _default_system_prompt(self) -> str:
        """Get the default system prompt."""
        return """You are a financial fraud detection expert AI agent.

Your role is to analyze transactions and provide:
1. A clear risk classification (LOW, MEDIUM, or HIGH)
2. A concise explanation based on the provided context
3. A recommended action (ALLOW, FLAG, or BLOCK)

Rules:
- Base your analysis on the provided transaction data and retrieved knowledge
- Do not hallucinate information not provided
- Be conservative: when in doubt, recommend FLAG over ALLOW
- Keep explanations clear and actionable
- Always respond in valid JSON format"""

    def _mock_response(self, prompt: str) -> Dict[str, Any]:
        """
        Generate a mock response when LLM is unavailable.
        Uses rule-based logic for demonstration.
        """
        import re

        # Check if this is a chat query (has "User Question:" in prompt)
        if "User Question:" in prompt:
            return self._mock_chat_response(prompt)

        # Extract risk score from prompt if possible (for transaction analysis)
        risk_score = 0.5

        # Try multiple patterns to extract risk score
        patterns = [
            r"- Risk Score:\s*([0-9.]+)",
            r"Risk Score:\s*([0-9.]+)",
            r"risk_score[:\s]+([0-9.]+)",
            r"'risk_score':\s*([0-9.]+)",
            r'"risk_score":\s*([0-9.]+)',
        ]

        for pattern in patterns:
            match = re.search(pattern, prompt)
            if match:
                try:
                    risk_score = float(match.group(1))
                    print(f"Extracted risk score: {risk_score} using pattern: {pattern}")
                    break
                except ValueError:
                    continue

        # Rule-based decision
        if risk_score >= 0.7:
            decision = "HIGH"
            action = "BLOCK" if risk_score >= 0.9 else "FLAG"
        elif risk_score >= 0.3:
            decision = "MEDIUM"
            action = "FLAG"
        else:
            decision = "LOW"
            action = "ALLOW"

        return {
            "decision": decision,
            "explanation": f"Transaction assessed with ML risk score of {risk_score:.2f}. "
                          f"Based on the risk analysis and fraud patterns, this transaction "
                          f"is classified as {decision} risk. "
                          f"Recommended action: {action}.",
            "action": action,
            "confidence": round(1 - abs(risk_score - (1 if action == "BLOCK" else 0)), 2),
        }

    def _mock_chat_response(self, prompt: str) -> Dict[str, Any]:
        """
        Generate a mock response for chat queries.
        Extracts knowledge from prompt and generates an answer.
        """
        import re

        # Extract the retrieved knowledge section
        answer = "Based on the fraud detection knowledge base, I can provide the following information: "
        confidence = 0.8

        # Try to extract knowledge entries from the prompt
        knowledge_pattern = r"\[(\d+)\]\s*\(([^)]+)\)\s*([^()]+?)(?:\s*\(relevance:|$)"
        matches = re.findall(knowledge_pattern, prompt, re.DOTALL)

        if matches:
            # Use the top relevant knowledge to construct an answer
            for i, (num, category, content) in enumerate(matches[:2], 1):
                content = content.strip()
                answer += f"({category.upper()}) {content} "

            confidence = 0.85
        else:
            answer += "The knowledge base contains information about fraud patterns, transaction types, risk thresholds, and behavioral indicators."

        return {
            "answer": answer,
            "sources": [],  # Will be populated by the agent
            "confidence": confidence,
        }


# Singleton instance
llm_service = LLMService()
