"""
API Routes for AI Agent.
Endpoints for agent analysis and chat.
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, Any, Optional, List
from app.ai.llm.groq_service import groq_service
from app.ai.agent.agent import fraud_agent
from app.ai.rag.embedding import embedding_service
from app.schemas.transaction import TransactionPredictRequest

router = APIRouter()


class TransactionAnalyzeRequest(TransactionPredictRequest):
    """Request schema for agent analysis - extends prediction request."""
    include_reasoning: bool = Field(
        default=True,
        description="Whether to include LLM reasoning in response"
    )


class TransactionAnalyzeResponse(BaseModel):
    """Response schema for agent analysis."""
    transaction_id: str
    timestamp: str
    ml_analysis: Dict[str, Any]
    agent_decision: Dict[str, Any]
    retrieved_knowledge: List[Dict[str, str]]


class ChatRequest(BaseModel):
    """Request schema for agent chat."""
    query: str = Field(..., description="User's question")
    transaction_context: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Optional transaction context"
    )


class ChatResponse(BaseModel):
    """Response schema for agent chat."""
    answer: str
    sources: List[str]
    confidence: float


@router.on_event("startup")
async def startup_agent():
    """Initialize the fraud detection agent on startup."""
    fraud_agent.initialize()


@router.post("/analyze", response_model=TransactionAnalyzeResponse)
def analyze_transaction(request: TransactionAnalyzeRequest):
    """
    Analyze a transaction using the full AI agent pipeline.

    This endpoint:
    1. Uses ML model to get risk score
    2. Retrieves relevant fraud knowledge (RAG)
    3. Uses LLM to reason and provide explanation
    4. Returns structured decision with action recommendation

    **Use case:** Real-time fraud decisioning for transactions
    """
    try:
        transaction_data = {
            "step": request.step,
            "type": request.type,
            "amount": request.amount,
            "oldbalanceOrg": request.oldbalanceOrg,
            "newbalanceOrig": request.newbalanceOrig,
            "oldbalanceDest": request.oldbalanceDest,
            "newbalanceDest": request.newbalanceDest,
        }

        result = fraud_agent.analyze_transaction(
            transaction=transaction_data,
            include_reasoning=request.include_reasoning,
        )

        return TransactionAnalyzeResponse(**result)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")


@router.post("/chat", response_model=ChatResponse)
def agent_chat(request: ChatRequest):
    """
    Chat with the fraud detection AI agent (fast mode).
    
    Ask questions about:
    - Fraud patterns and risk indicators
    - Transaction risk assessment
    - Fraud prevention strategies
    - Financial security best practices
    """
    try:
        result = groq_service.generate_fraud_response(request.query)
        
        return ChatResponse(
            answer=result.get("answer", "Unable to process your question."),
            sources=result.get("sources", []),
            confidence=result.get("confidence", 0.5),
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Chat failed: {str(e)}")


@router.get("/knowledge-base")
def get_knowledge_base():
    """
    Get all fraud detection knowledge entries.

    Returns the complete knowledge base used by the RAG system.
    """
    from app.ai.rag.knowledge_base import KNOWLEDGE_BASE
    return {
        "total_entries": len(KNOWLEDGE_BASE),
        "knowledge": KNOWLEDGE_BASE,
    }


@router.post("/knowledge-base/rebuild")
def rebuild_knowledge_index():
    """
    Rebuild the FAISS index for the knowledge base.

    Use this endpoint after updating the knowledge base content.
    """
    try:
        embedding_service.rebuild_index()
        return {
            "status": "success",
            "message": "Knowledge index rebuilt successfully",
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Rebuild failed: {str(e)}")