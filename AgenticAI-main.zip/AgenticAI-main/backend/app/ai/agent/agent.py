"""
AI Agent for fraud detection.
Orchestrates ML model, RAG retrieval, and LLM reasoning.
"""

import json
from typing import Dict, Any, Optional
from datetime import datetime

from app.services.ml_service import ml_service
from app.ai.rag.retrieval import retrieval_service, create_transaction_query
from app.ai.rag.embedding import embedding_service
from app.ai.llm.llm_service import llm_service


class FraudDetectionAgent:
    """
    AI Agent that combines ML predictions with RAG and LLM reasoning.

    Pipeline:
    1. Receive transaction data
    2. Call ML model → risk_score
    3. Create query from transaction
    4. Call RAG → retrieve relevant knowledge
    5. Build prompt with context
    6. Call LLM → reasoning and decision
    7. Return structured output
    """

    def __init__(self):
        """Initialize the fraud detection agent."""
        self.ml_service = ml_service
        self.retrieval_service = retrieval_service
        self.llm_service = llm_service
        self._initialized = False

    def initialize(self) -> None:
        """Initialize all services (load models, indices)."""
        print("Initializing Fraud Detection Agent...")
        self.ml_service.load_model()
        embedding_service.load_or_create_index()
        self._initialized = True
        print("Fraud Detection Agent ready!")

    def analyze_transaction(
        self,
        transaction: Dict[str, Any],
        include_reasoning: bool = True,
    ) -> Dict[str, Any]:
        """
        Analyze a transaction using the full AI pipeline.

        Args:
            transaction: Transaction data with fields:
                - step, type, amount, oldbalanceOrg, newbalanceOrig,
                  oldbalanceDest, newbalanceDest
            include_reasoning: Whether to include LLM reasoning

        Returns:
            Structured analysis result with:
                - risk_score (from ML)
                - prediction (from ML)
                - decision (LOW/MEDIUM/HIGH)
                - explanation (from LLM)
                - action (ALLOW/FLAG/BLOCK)
                - retrieved_knowledge (context used)
        """
        # Step 1: Get ML prediction
        ml_result = self.ml_service.predict(
            step=transaction.get("step", 0),
            transaction_type=transaction.get("type", "UNKNOWN"),
            amount=transaction.get("amount", 0),
            oldbalanceOrg=transaction.get("oldbalanceOrg", 0),
            newbalanceOrig=transaction.get("newbalanceOrig", 0),
            oldbalanceDest=transaction.get("oldbalanceDest", 0),
            newbalanceDest=transaction.get("newbalanceDest", 0),
        )

        risk_score = float(ml_result["risk_score"])
        ml_prediction = int(ml_result["prediction"])

        # Step 2: Create query for RAG
        query = create_transaction_query(
            transaction_type=transaction.get("type", "UNKNOWN"),
            amount=transaction.get("amount", 0),
            oldbalanceOrg=transaction.get("oldbalanceOrg", 0),
            newbalanceOrig=transaction.get("newbalanceOrig", 0),
            risk_score=risk_score,
        )

        # Step 3: Retrieve relevant knowledge
        retrieved_knowledge = self.retrieval_service.retrieve(query)
        context_formatted = self.retrieval_service.format_context(retrieved_knowledge)

        # Step 4: Build prompt for LLM
        prompt = self._build_prompt(
            transaction=transaction,
            risk_score=risk_score,
            ml_prediction=ml_prediction,
            context=context_formatted,
        )

        # Step 5: Get LLM reasoning (or use mock)
        if include_reasoning:
            llm_result = self.llm_service.generate_response(prompt)
        else:
            llm_result = self._rule_based_decision(risk_score)

        # Step 6: Compile final result
        result = {
            "transaction_id": transaction.get("id", "N/A"),
            "timestamp": datetime.utcnow().isoformat(),
            "ml_analysis": {
                "risk_score": risk_score,
                "prediction": ml_prediction,
                "is_high_risk": bool(ml_result.get("is_high_risk", False)),
            },
            "agent_decision": {
                "decision": llm_result.get("decision", "UNKNOWN"),
                "explanation": llm_result.get("explanation", ""),
                "action": llm_result.get("action", "FLAG"),
                "confidence": llm_result.get("confidence", 0.5),
            },
            "retrieved_knowledge": [
                {"id": k["id"], "category": k["category"]}
                for k in retrieved_knowledge
            ],
        }

        return result

    def _build_prompt(
        self,
        transaction: Dict[str, Any],
        risk_score: float,
        ml_prediction: int,
        context: str,
    ) -> str:
        """
        Build the prompt for LLM reasoning.

        Args:
            transaction: Transaction data
            risk_score: ML-predicted risk score
            ml_prediction: ML binary prediction (0/1)
            context: Retrieved knowledge context

        Returns:
            Formatted prompt string
        """
        transaction_summary = f"""
Transaction Details:
- Type: {transaction.get('type', 'UNKNOWN')}
- Amount: ${transaction.get('amount', 0):,.2f}
- Sender Balance Before: ${transaction.get('oldbalanceOrg', 0):,.2f}
- Sender Balance After: ${transaction.get('newbalanceOrig', 0):,.2f}
- Receiver Balance Before: ${transaction.get('oldbalanceDest', 0):,.2f}
- Receiver Balance After: ${transaction.get('newbalanceDest', 0):,.2f}
"""

        ml_summary = f"""
ML Model Analysis:
- Risk Score: {risk_score:.4f}
- Binary Prediction: {'FRAUD' if ml_prediction == 1 else 'LEGITIMATE'}
"""

        prompt = f"""
You are a financial fraud detection expert AI agent.

{transaction_summary}
{ml_summary}

Relevant Fraud Detection Knowledge:
{context}

Based on the transaction data, ML risk assessment, and fraud detection knowledge above:

1. Classify the risk level: LOW, MEDIUM, or HIGH
2. Provide a clear explanation referencing the specific risk factors
3. Recommend an action: ALLOW, FLAG, or BLOCK

Respond ONLY in this JSON format:
{{
  "decision": "LOW|MEDIUM|HIGH",
  "explanation": "Your explanation here",
  "action": "ALLOW|FLAG|BLOCK",
  "confidence": 0.0-1.0
}}
"""
        return prompt

    def _rule_based_decision(self, risk_score: float) -> Dict[str, Any]:
        """
        Fallback rule-based decision when LLM is unavailable.

        Args:
            risk_score: ML-predicted risk score

        Returns:
            Decision dictionary
        """
        if risk_score >= 0.7:
            decision = "HIGH"
            action = "BLOCK" if risk_score >= 0.9 else "FLAG"
            confidence = min(risk_score + 0.1, 1.0)
        elif risk_score >= 0.3:
            decision = "MEDIUM"
            action = "FLAG"
            confidence = 0.7
        else:
            decision = "LOW"
            action = "ALLOW"
            confidence = 1 - risk_score

        return {
            "decision": decision,
            "explanation": f"ML risk score of {risk_score:.2f} indicates {decision} risk. "
                          f"Automated rule-based decision: {action}.",
            "action": action,
            "confidence": round(confidence, 2),
        }

    def chat(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Answer a user query using RAG + LLM.

        Args:
            query: User's question
            context: Optional transaction context

        Returns:
            Response with answer and sources
        """
        # Retrieve relevant knowledge
        retrieved = self.retrieval_service.retrieve(query)
        context_formatted = self.retrieval_service.format_context(retrieved)

        # Build prompt
        prompt = f"""
You are a fraud detection assistant. Answer the user's question using the retrieved knowledge.

User Question: {query}

Retrieved Knowledge:
{context_formatted}

Provide a clear, accurate answer based on the knowledge above. If the knowledge doesn't
contain relevant information, say so.

Respond in JSON format:
{{
  "answer": "Your answer here",
  "sources": ["KB001", "KB002"],
  "confidence": 0.0-1.0
}}
"""

        result = self.llm_service.generate_response(prompt)
        result["sources"] = [k["id"] for k in retrieved]

        return result


# Singleton instance
fraud_agent = FraudDetectionAgent()
