"""
Training script for fraud detection model.
Uses PaySim dataset to train a RandomForestClassifier.
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
import joblib
import os

# Paths
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)
DATA_PATH = os.path.join(PROJECT_ROOT, "../paysim.csv")
MODEL_PATH = os.path.join(PROJECT_ROOT, "app/models/fraud_model.pkl")
ENCODER_PATH = os.path.join(PROJECT_ROOT, "app/models/type_encoder.pkl")

# Features to use
FEATURE_COLUMNS = [
    "amount",
    "oldbalanceOrg",
    "newbalanceOrig",
    "oldbalanceDest",
    "newbalanceDest",
]

TARGET_COLUMN = "isFraud"
TYPE_COLUMN = "type"


def load_and_preprocess_data(filepath: str) -> pd.DataFrame:
    """Load and preprocess the PaySim dataset."""
    print("Loading dataset...")
    df = pd.read_csv(filepath)

    print(f"Dataset shape: {df.shape}")
    print(f"Fraud distribution:\n{df[TARGET_COLUMN].value_counts()}")

    return df


def encode_transaction_type(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Encode the 'type' column using label encoding."""
    type_mapping = {
        "CASH_OUT": 0,
        "DEBIT": 1,
        "PAYMENT": 2,
        "TRANSFER": 3,
        "CASH_IN": 4,
    }

    df["type_encoded"] = df[TYPE_COLUMN].map(type_mapping)

    # Fill unknown types with -1
    df["type_encoded"] = df["type_encoded"].fillna(-1)

    print(f"Type encoding mapping: {type_mapping}")

    return df, type_mapping


def prepare_features(df: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
    """Prepare feature matrix and target vector."""
    feature_cols = ["type_encoded"] + FEATURE_COLUMNS

    X = df[feature_cols].values
    y = df[TARGET_COLUMN].values

    print(f"Feature matrix shape: {X.shape}")
    print(f"Target vector shape: {y.shape}")

    return X, y


def train_model(X: np.ndarray, y: np.ndarray) -> RandomForestClassifier:
    """Train the RandomForest model."""
    print("\nSplitting data (80/20)...")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    print(f"Training set: {X_train.shape}, Test set: {X_test.shape}")

    print("\nTraining RandomForestClassifier...")
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=15,
        min_samples_split=5,
        min_samples_leaf=2,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1,
    )

    model.fit(X_train, y_train)

    # Evaluate
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    print("\n" + "="*50)
    print("MODEL EVALUATION")
    print("="*50)
    print(f"\nROC-AUC Score: {roc_auc_score(y_test, y_proba):.4f}")
    print(f"\nConfusion Matrix:\n{confusion_matrix(y_test, y_pred)}")
    print(f"\nClassification Report:\n{classification_report(y_test, y_pred)}")

    # Feature importance
    feature_names = ["type_encoded"] + FEATURE_COLUMNS
    importance_df = pd.DataFrame({
        "feature": feature_names,
        "importance": model.feature_importances_
    }).sort_values("importance", ascending=False)

    print("\nFeature Importances:")
    print(importance_df)

    return model


def save_model(model: RandomForestClassifier, type_mapping: dict):
    """Save the trained model and encoder."""
    print(f"\nSaving model to: {MODEL_PATH}")
    joblib.dump(model, MODEL_PATH)

    print(f"Saving type encoder to: {ENCODER_PATH}")
    joblib.dump(type_mapping, ENCODER_PATH)

    print("Model training complete!")


def main():
    print("="*50)
    print("FRAUD DETECTION MODEL TRAINING")
    print("="*50)

    # Load data
    df = load_and_preprocess_data(DATA_PATH)

    # Encode type column
    df, type_mapping = encode_transaction_type(df)

    # Prepare features
    X, y = prepare_features(df)

    # Train model
    model = train_model(X, y)

    # Save model
    save_model(model, type_mapping)


if __name__ == "__main__":
    main()
