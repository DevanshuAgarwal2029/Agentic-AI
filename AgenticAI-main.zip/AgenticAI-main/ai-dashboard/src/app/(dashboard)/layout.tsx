"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuthStore } from "@/lib/store/useAuthStore";
import { Sidebar } from "@/components/layout/Sidebar";
import { Navbar } from "@/components/layout/Navbar";
import { AIPanel } from "@/components/ui/AIPanel";
import { useAIPanelStore } from "@/lib/store/useAIPanelStore";
import { cn } from "@/lib/utils/cn";
import { FinanceAssistant } from "@/components/ui/FinanceAssistant";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();
  const { isOpen, selectedTransaction, closePanel } = useAIPanelStore();
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    if (!isAuthenticated) {
      router.push("/login");
    }
  }, [isAuthenticated, router]);

  // Prevent hydration mismatch - wait for client-side mount
  if (!isMounted) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-gray-200 rounded-full animate-spin border-t-gray-900" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar />
      <div
        className={cn(
          "pl-64 transition-all duration-300",
          isOpen ? "mr-[400px]" : "mr-0",
        )}
      >
        <Navbar />
        <main className="p-6">{children}</main>
      </div>
      <AIPanel
        isOpen={isOpen}
        onClose={closePanel}
        transaction={selectedTransaction}
        apiBaseUrl="http://localhost:8000"
      />
      <FinanceAssistant />
    </div>
  );
}
