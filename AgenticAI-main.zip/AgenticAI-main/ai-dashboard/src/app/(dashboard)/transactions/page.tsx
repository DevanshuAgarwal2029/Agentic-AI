"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useAIPanelStore } from "@/lib/store/useAIPanelStore";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import {
  Activity,
  TrendingUp,
  ShieldCheck,
  AlertTriangle,
  DollarSign,
  Download,
} from "lucide-react";

interface Transaction {
  id: number;
  step: number;
  type: string;
  amount: number;
  oldbalanceOrg: number;
  newbalanceOrig: number;
  oldbalanceDest: number;
  newbalanceDest: number;
  isFraud: boolean;
  risk_score: number | null;
}

interface Stats {
  total_transactions: number;
  fraud_detected: number;
  fraud_rate: number;
}

interface ModelMetrics {
  accuracy: number;
  precision: number;
  recall: number;
  f1_score: number;
}

const API_BASE = "http://localhost:8000";
const chartColors = {
  legit: "rgb(16, 185, 129)",
  fraud: "rgb(239, 68, 68)",
  metric: "rgb(37, 99, 235)",
};

export default function TransactionsPage() {
  const { selectTransaction } = useAIPanelStore();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [modelMetrics, setModelMetrics] = useState<ModelMetrics | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const reportRef = useRef<HTMLDivElement>(null);

  const reportDate = useMemo(
    () =>
      new Date().toLocaleDateString("en-US", {
        month: "long",
        day: "numeric",
        year: "numeric",
      }),
    [],
  );

  useEffect(() => {
    fetchTransactions();
    fetchStats();
    fetchModelMetrics();
  }, []);

  const fetchTransactions = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/transactions?limit=500`);
      if (!response.ok) throw new Error("Failed to fetch transactions");
      const data = await response.json();
      setTransactions(data.transactions);
    } catch (err) {
      setError("Unable to load transactions. Ensure backend is running.");
    } finally {
      setIsLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/stats`);
      if (!response.ok) throw new Error("Failed to fetch stats");
      const data = await response.json();
      setStats(data);
    } catch (err) {
      console.error("Failed to fetch stats:", err);
    }
  };

  const fetchModelMetrics = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/model-performance`);
      if (!response.ok) throw new Error("Failed to fetch model metrics");
      const data = await response.json();
      setModelMetrics(data);
    } catch (err) {
      console.error("Failed to fetch model metrics:", err);
      setModelMetrics({
        accuracy: 0.95,
        precision: 0.92,
        recall: 0.88,
        f1_score: 0.9,
      });
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
    }).format(value);
  };

  const pieData = stats
    ? [
        {
          name: "Legitimate",
          value: stats.total_transactions - stats.fraud_detected,
          color: chartColors.legit,
        },
        {
          name: "Fraudulent",
          value: stats.fraud_detected,
          color: chartColors.fraud,
        },
      ]
    : [];

  const barData = modelMetrics
    ? [
        { name: "Accuracy", value: modelMetrics.accuracy * 100 },
        { name: "Precision", value: modelMetrics.precision * 100 },
        { name: "Recall", value: modelMetrics.recall * 100 },
        { name: "F1 Score", value: modelMetrics.f1_score * 100 },
      ]
    : [];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-gray-200 rounded-full animate-spin border-t-gray-900 mx-auto mb-4" />
          <p className="text-gray-500">Loading transactions...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <Card className="border-red-200 bg-red-50 max-w-md">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-600 mx-auto mb-3" />
            <h3 className="text-sm font-medium text-red-800 mb-1">
              Failed to Load Data
            </h3>
            <p className="text-xs text-red-600">{error}</p>
            <Button
              onClick={fetchTransactions}
              variant="primary"
              size="sm"
              className="mt-4"
            >
              Retry
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Transactions</h2>
          <p className="text-gray-500 mt-1">
            View and analyze all transactions with AI-powered fraud detection
          </p>
        </div>
        <Button onClick={fetchTransactions} variant="ghost" size="sm">
          <Activity className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Stats Grid */}
      {stats && (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                Total
              </CardTitle>
              <DollarSign className="w-4 h-4 text-gray-700" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">
                {stats.total_transactions.toLocaleString()}
              </div>
              <p className="text-xs text-gray-500">Transactions loaded</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                Fraud Detected
              </CardTitle>
              <ShieldCheck className="w-4 h-4 text-gray-700" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">
                {stats.fraud_detected.toLocaleString()}
              </div>
              <p className="text-xs text-gray-500">Flagged transactions</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                Fraud Rate
              </CardTitle>
              <AlertTriangle className="w-4 h-4 text-gray-700" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">
                {stats.fraud_rate.toFixed(2)}%
              </div>
              <p className="text-xs text-gray-500">Of total transactions</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                AI Status
              </CardTitle>
              <TrendingUp className="w-4 h-4 text-gray-700" />
            </CardHeader>
            <CardContent>
              <div className="text-sm font-semibold text-green-600">Active</div>
              <p className="text-xs text-gray-500">Ready for analysis</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Transactions Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Transaction List</CardTitle>
              <CardDescription>
                Click on a transaction to analyze with AI
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-100">
                  <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    ID
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Amount
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Sender Balance
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Fraud
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {transactions.map((txn) => (
                  <tr
                    key={txn.id}
                    className="hover:bg-gray-50 transition-colors cursor-pointer"
                    onClick={() =>
                      selectTransaction({
                        id: txn.id,
                        step: txn.step,
                        type: txn.type,
                        amount: txn.amount,
                        oldbalanceOrg: txn.oldbalanceOrg,
                        newbalanceOrig: txn.newbalanceOrig,
                        oldbalanceDest: txn.oldbalanceDest,
                        newbalanceDest: txn.newbalanceDest,
                        isFraud: txn.isFraud,
                        risk_score: txn.risk_score,
                      })
                    }
                  >
                    <td className="py-3 px-4">
                      <span className="text-sm font-medium text-gray-900">
                        #{txn.id}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-sm text-gray-700">{txn.type}</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-sm font-semibold text-gray-900">
                        {formatCurrency(txn.amount)}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-xs text-gray-500">
                        <div>Before: {formatCurrency(txn.oldbalanceOrg)}</div>
                        <div>After: {formatCurrency(txn.newbalanceOrig)}</div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      {txn.isFraud ? (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-700">
                          <AlertTriangle className="w-3 h-3 mr-1" />
                          Yes
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700">
                          <ShieldCheck className="w-3 h-3 mr-1" />
                          No
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {transactions.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500 text-sm">No transactions found</p>
              <Button
                onClick={fetchTransactions}
                variant="primary"
                size="sm"
                className="mt-4"
              >
                Load Data
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
