"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { MessageCircle, X, Send, Sparkles, AlertTriangle } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

type ChatMessage = {
  role: "user" | "assistant";
  text: string;
  meta?: {
    sources?: string[];
    confidence?: number;
  };
};

const API_BASE =
  process.env.NEXT_PUBLIC_API_BASE_URL?.trim() || "http://localhost:8000";

const QUICK_QUESTIONS = [
  "What are the common fraud indicators?",
  "How does transaction risk scoring work?",
  "What should I do about suspicious activity?",
  "How can I prevent financial fraud?",
];

export function FinanceAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  const canSend = useMemo(
    () => !isLoading && query.trim().length > 0,
    [isLoading, query],
  );

  const toggleOpen = () => setIsOpen((prev) => !prev);

  useEffect(() => {
    if (!isOpen) return;
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [isOpen, messages.length, isLoading]);

  const normalizeAnswer = (raw: unknown): string => {
    const text = typeof raw === "string" ? raw.trim() : "";
    if (!text) return "Sorry, I could not answer that.";
    return text;
  };

  const sendMessage = async (messageText?: string) => {
    const textToSend = messageText || query.trim();
    if (!textToSend) return;

    setError(null);
    setMessages((prev) => [...prev, { role: "user", text: textToSend }]);
    setQuery("");
    setIsLoading(true);

    try {
      const response = await fetch(`${API_BASE}/api/agent/chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          query: textToSend,
          transaction_context: null,
        }),
      });

      if (!response.ok) {
        throw new Error("Unable to reach AI assistant");
      }

      const data = await response.json();

      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          text: normalizeAnswer(data?.answer),
          meta: {
            sources: Array.isArray(data?.sources) ? data.sources : [],
            confidence:
              typeof data?.confidence === "number" ? data.confidence : undefined,
          },
        },
      ]);
    } catch (err) {
      setError("Couldn’t reach the AI service. Please try again in a moment.");
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          text: "I couldn’t connect to the AI service. Please try again.",
          meta: { sources: [], confidence: 0 },
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3">
      {isOpen && (
        <div className="w-[440px] max-w-full rounded-3xl shadow-[0_40px_120px_rgba(15,23,42,0.18)] overflow-hidden bg-white border border-slate-200">
          <div className="relative bg-gradient-to-r from-slate-900 to-slate-800 px-7 py-7 text-white">
            <button
              onClick={toggleOpen}
              className="absolute top-4 right-4 rounded-full p-2 text-white hover:bg-white/20 transition"
              aria-label="Close assistant"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs text-white/90">
                  <Sparkles className="h-3.5 w-3.5" />
                  <span>Fraud guidance assistant</span>
                </div>
                <h2 className="mt-3 text-xl font-semibold tracking-tight">
                  Finance Assistant
                </h2>
                <p className="text-white/70 text-sm mt-1">
                  Ask about fraud signals, risk scoring, and prevention.
                </p>
              </div>
            </div>

            <div className="mt-5 flex items-center gap-2 bg-white rounded-2xl px-4 py-3 shadow-lg">
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask a question..."
                className="flex-1 bg-transparent text-gray-900 placeholder-gray-400 outline-none text-sm"
              />
              <button
                onClick={() => sendMessage()}
                disabled={!canSend}
                className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-900 text-white hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-50 transition"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="px-6 py-5">
            {error && (
              <div className="mb-4 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3">
                <div className="flex items-start gap-2 text-amber-900">
                  <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium">Assistant unavailable</p>
                    <p className="text-xs text-amber-800 mt-0.5">{error}</p>
                  </div>
                </div>
              </div>
            )}
            {messages.length === 0 ? (
              <div>
                <h3 className="text-lg font-semibold text-slate-900 mb-1">
                  Want help getting started?
                </h3>
                <p className="text-sm text-slate-500 mb-4">
                  Click a question below or ask your own.
                </p>

                <div className="space-y-3">
                  {QUICK_QUESTIONS.map((question, index) => (
                    <button
                      key={index}
                      onClick={() => sendMessage(question)}
                      className="w-full text-left rounded-2xl border border-slate-200 bg-slate-50 px-5 py-4 text-sm font-medium text-slate-900 hover:bg-slate-100 hover:border-slate-300 transition"
                    >
                      {question}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div
                ref={scrollRef}
                className="max-h-[360px] space-y-3 overflow-y-auto pr-1"
              >
                {messages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${
                      message.role === "user" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`max-w-[88%] rounded-3xl px-4 py-3 text-sm leading-6 shadow-sm ${
                        message.role === "assistant"
                          ? "bg-slate-50 text-slate-900 border border-slate-200"
                          : "bg-slate-900 text-white"
                      }`}
                    >
                      <div className="whitespace-pre-wrap break-words prose prose-sm prose-slate m-0 max-w-none">
                        <ReactMarkdown remarkPlugins={[remarkGfm]}>
                          {message.text}
                        </ReactMarkdown>
                      </div>

                      {message.role === "assistant" &&
                        (message.meta?.sources?.length ||
                          typeof message.meta?.confidence === "number") && (
                          <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-slate-200 pt-3">
                            {typeof message.meta?.confidence === "number" && (
                              <span className="inline-flex items-center rounded-full bg-white px-2.5 py-1 text-xs font-medium text-slate-700 border border-slate-200">
                                Confidence:{" "}
                                {Math.round(message.meta.confidence * 100)}%
                              </span>
                            )}
                            {message.meta?.sources?.length ? (
                              <span className="inline-flex items-center rounded-full bg-white px-2.5 py-1 text-xs font-medium text-slate-700 border border-slate-200">
                                Sources: {message.meta.sources.join(", ")}
                              </span>
                            ) : null}
                          </div>
                        )}
                    </div>
                  </div>
                ))}

                {isLoading && (
                  <div className="flex justify-start">
                    <div className="rounded-3xl bg-slate-50 border border-slate-200 px-4 py-3 text-sm text-slate-700">
                      Thinking…
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      <button
        onClick={toggleOpen}
        className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-slate-900 to-slate-800 text-white shadow-xl hover:shadow-2xl transition hover:scale-105 border border-white/10"
        aria-label="Open finance assistant"
      >
        <MessageCircle className="w-7 h-7" />
      </button>
    </div>
  );
}
