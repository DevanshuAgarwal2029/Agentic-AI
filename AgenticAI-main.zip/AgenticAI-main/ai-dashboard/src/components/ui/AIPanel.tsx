"use client";

import { useState, useEffect } from "react";
import {
  Bot,
  X,
  ShieldAlert,
  ShieldCheck,
  TrendingUp,
  Activity,
  ChevronRight,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Card, CardContent } from "@/components/ui/Card";
import { cn } from "@/lib/utils/cn";

export interface TransactionContext {
  id?: string | number;
  step?: number;
  type: string;
  amount: number;
  oldbalanceOrg: number;
  newbalanceOrig: number;
  oldbalanceDest: number;
  newbalanceDest: number;
  isFraud?: boolean;
  risk_score?: number | null;
}

interface MLAnalysis {
  risk_score: number;
  prediction: number;
  is_high_risk: boolean;
}

interface AIAnalysisResult {
  decision: string;
  explanation: string;
  action: string;
  confidence: number;
}

interface FullAnalysisResponse {
  transaction_id: string;
  timestamp: string;
  ml_analysis: MLAnalysis;
  agent_decision: AIAnalysisResult;
  retrieved_knowledge?: Array<{ id: string; category: string }>;
}

interface AIPanelProps {
  isOpen: boolean;
  onClose: () => void;
  transaction?: TransactionContext | null;
  apiBaseUrl?: string;
}

const RISK_COLORS = {
  low: {
    bg: "bg-green-50",
    border: "border-green-200",
    text: "text-green-700",
    badge: "bg-green-100 text-green-800",
    icon: "text-green-600",
  },
  medium: {
    bg: "bg-yellow-50",
    border: "border-yellow-200",
    text: "text-yellow-700",
    badge: "bg-yellow-100 text-yellow-800",
    icon: "text-yellow-600",
  },
  high: {
    bg: "bg-red-50",
    border: "border-red-200",
    text: "text-red-700",
    badge: "bg-red-100 text-red-800",
    icon: "text-red-600",
  },
};

const ACTION_COLORS = {
  ALLOW: "text-green-600 bg-green-50 border-green-200",
  FLAG: "text-yellow-600 bg-yellow-50 border-yellow-200",
  BLOCK: "text-red-600 bg-red-50 border-red-200",
};

export function AIPanel({
  isOpen,
  onClose,
  transaction,
  apiBaseUrl = "http://localhost:8000",
}: AIPanelProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [fullAnalysis, setFullAnalysis] = useState<FullAnalysisResponse | null>(
    null,
  );
  const [error, setError] = useState<string | null>(null);

  // Helper: Get risk level from score (CRITICAL: Single source of truth)
  const getRiskLevel = (score: number): "low" | "medium" | "high" => {
    if (score >= 0.7) return "high";
    if (score >= 0.4) return "medium";
    return "low";
  };

  useEffect(() => {
    if (transaction && isOpen) {
      analyzeTransaction();
    }
  }, [transaction, isOpen]);

  const analyzeTransaction = async () => {
    if (!transaction) return;

    setIsLoading(true);
    setError(null);
    setFullAnalysis(null);

    try {
      const response = await fetch(`${apiBaseUrl}/api/agent/analyze`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          step: transaction.step || 0,
          type: transaction.type,
          amount: transaction.amount,
          oldbalanceOrg: transaction.oldbalanceOrg,
          newbalanceOrig: transaction.newbalanceOrig,
          oldbalanceDest: transaction.oldbalanceDest,
          newbalanceDest: transaction.newbalanceDest,
          include_reasoning: true,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to analyze transaction");
      }

      const data: FullAnalysisResponse = await response.json();
      setFullAnalysis(data);
    } catch (err) {
      setError(
        "Unable to connect to AI service. Please ensure the backend is running.",
      );
    } finally {
      setIsLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
    }).format(value);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-[400px] bg-white shadow-2xl transform transition-transform duration-300 ease-in-out flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-gray-900 to-gray-800 text-white">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center backdrop-blur-sm">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold text-sm">AI Analysis</h3>
            <p className="text-xs text-gray-400">Powered by ML + RAG</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          aria-label="Close panel"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-gray-50">
        {/* Context Section */}
        {transaction && (
          <Card className="border-gray-200 shadow-sm">
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center gap-2 text-gray-700 font-medium">
                <Activity className="w-4 h-4" />
                <span className="text-sm">Transaction Context</span>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Type</span>
                  <span className="font-medium text-gray-900">
                    {transaction.type}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Amount</span>
                  <span className="font-semibold text-gray-900">
                    {formatCurrency(transaction.amount)}
                  </span>
                </div>
                {fullAnalysis?.ml_analysis && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">ML Risk Score</span>
                    <span
                      className={cn(
                        "font-semibold px-2 py-0.5 rounded-full text-xs",
                        fullAnalysis.ml_analysis.risk_score >= 0.7
                          ? "bg-red-100 text-red-700"
                          : fullAnalysis.ml_analysis.risk_score >= 0.4
                            ? "bg-yellow-100 text-yellow-700"
                            : "bg-green-100 text-green-700",
                      )}
                    >
                      {(fullAnalysis.ml_analysis.risk_score * 100).toFixed(1)}%
                    </span>
                  </div>
                )}
                <div className="pt-2 border-t border-gray-100">
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-gray-400">Sender Before</span>
                      <p className="font-medium text-gray-700">
                        {formatCurrency(transaction.oldbalanceOrg)}
                      </p>
                    </div>
                    <div>
                      <span className="text-gray-400">Sender After</span>
                      <p className="font-medium text-gray-700">
                        {formatCurrency(transaction.newbalanceOrig)}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Loading State */}
        {isLoading && (
          <Card className="border-gray-200 shadow-sm">
            <CardContent className="p-6">
              <div className="flex flex-col items-center justify-center space-y-3">
                <div className="relative">
                  <div className="w-12 h-12 border-4 border-gray-200 rounded-full" />
                  <div className="absolute top-0 left-0 w-12 h-12 border-4 border-gray-900 rounded-full border-t-transparent animate-spin" />
                </div>
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-700">
                    Analyzing transaction...
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    Consulting ML model + knowledge base
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Error State */}
        {error && (
          <Card className="border-red-200 bg-red-50">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <ShieldAlert className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-red-800">
                    Analysis Unavailable
                  </p>
                  <p className="text-xs text-red-600 mt-1">{error}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Analysis Result - Data from Real API */}
        {fullAnalysis && !isLoading && (
          <>
            {/* Risk Assessment Card - Uses ML risk_score for consistency */}
            <Card
              className={cn(
                "border-2 shadow-sm",
                getRiskLevel(fullAnalysis.ml_analysis.risk_score) === "high"
                  ? RISK_COLORS.high.border
                  : getRiskLevel(fullAnalysis.ml_analysis.risk_score) ===
                      "medium"
                    ? RISK_COLORS.medium.border
                    : RISK_COLORS.low.border,
              )}
            >
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {getRiskLevel(fullAnalysis.ml_analysis.risk_score) ===
                    "high" ? (
                      <ShieldAlert
                        className={cn("w-5 h-5", RISK_COLORS.high.icon)}
                      />
                    ) : (
                      <ShieldCheck
                        className={cn("w-5 h-5", RISK_COLORS.low.icon)}
                      />
                    )}
                    <span className="text-sm font-medium text-gray-700">
                      Risk Assessment
                    </span>
                  </div>
                  <span
                    className={cn(
                      "px-3 py-1 rounded-full text-xs font-semibold uppercase",
                      getRiskLevel(fullAnalysis.ml_analysis.risk_score) ===
                        "high"
                        ? RISK_COLORS.high.badge
                        : getRiskLevel(fullAnalysis.ml_analysis.risk_score) ===
                            "medium"
                          ? RISK_COLORS.medium.badge
                          : RISK_COLORS.low.badge,
                    )}
                  >
                    {getRiskLevel(fullAnalysis.ml_analysis.risk_score)} risk
                  </span>
                </div>

                {/* ML Risk Score Display */}
                <div className="flex items-center justify-between text-sm pt-2 border-t border-gray-100">
                  <span className="text-gray-500">ML Score</span>
                  <span className="font-mono font-semibold text-gray-900">
                    {(fullAnalysis.ml_analysis.risk_score * 100).toFixed(1)}%
                  </span>
                </div>

                {/* Confidence Bar */}
                <div className="space-y-1 pt-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-gray-500">AI Confidence</span>
                    <span className="font-medium text-gray-700">
                      {Math.round(fullAnalysis.agent_decision.confidence * 100)}
                      %
                    </span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all duration-500",
                        fullAnalysis.agent_decision.confidence >= 0.8
                          ? "bg-green-500"
                          : fullAnalysis.agent_decision.confidence >= 0.5
                            ? "bg-yellow-500"
                            : "bg-red-500",
                      )}
                      style={{
                        width: `${fullAnalysis.agent_decision.confidence * 100}%`,
                      }}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* AI Explanation Card - Real API Response */}
            <Card className="border-gray-200 shadow-sm">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-2 text-gray-700 font-medium">
                  <TrendingUp className="w-4 h-4" />
                  <span className="text-sm">AI Explanation</span>
                </div>
                <p className="text-sm text-gray-600 leading-relaxed">
                  {fullAnalysis.agent_decision.explanation}
                </p>

                {/* Knowledge Sources */}
                {fullAnalysis.retrieved_knowledge &&
                  fullAnalysis.retrieved_knowledge.length > 0 && (
                    <div className="pt-3 border-t border-gray-100">
                      <p className="text-xs text-gray-500 mb-2">
                        Retrieved fraud patterns:
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {fullAnalysis.retrieved_knowledge.map((kb) => (
                          <span
                            key={kb.id}
                            className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded-md"
                          >
                            {kb.id}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                {/* Timestamp */}
                <div className="pt-3 border-t border-gray-100">
                  <p className="text-xs text-gray-400">
                    Analyzed at:{" "}
                    {new Date(fullAnalysis.timestamp).toLocaleString()}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Suggested Action Card - Real API Response */}
            <Card
              className={cn(
                "border-2 shadow-sm",
                ACTION_COLORS[
                  fullAnalysis.agent_decision
                    .action as keyof typeof ACTION_COLORS
                ] || ACTION_COLORS.FLAG,
              )}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4" />
                    <span className="text-sm font-medium text-gray-700">
                      Suggested Action
                    </span>
                  </div>
                  <span
                    className={cn(
                      "px-4 py-2 rounded-xl text-sm font-bold uppercase",
                      ACTION_COLORS[
                        fullAnalysis.agent_decision
                          .action as keyof typeof ACTION_COLORS
                      ] || ACTION_COLORS.FLAG,
                    )}
                  >
                    {fullAnalysis.agent_decision.action}
                  </span>
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  Based on ML analysis (score:{" "}
                  {(fullAnalysis.ml_analysis.risk_score * 100).toFixed(0)}%) and
                  fraud detection rules.
                </p>
              </CardContent>
            </Card>

            {/* Re-analyze Button */}
            <Button
              variant="ghost"
              size="sm"
              onClick={analyzeTransaction}
              className="w-full text-gray-500 hover:text-gray-700"
            >
              <Activity className="w-4 h-4 mr-2" />
              Re-analyze Transaction
            </Button>
          </>
        )}

        {/* No Transaction State */}
        {!transaction && !isLoading && !error && (
          <div className="text-center py-12">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gray-100 flex items-center justify-center">
              <Bot className="w-8 h-8 text-gray-400" />
            </div>
            <h4 className="text-sm font-medium text-gray-700">
              No Transaction Selected
            </h4>
            <p className="text-xs text-gray-500 mt-2 max-w-[200px] mx-auto">
              Click on a transaction in the table to get AI-powered analysis and
              recommendations.
            </p>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="px-5 py-3 bg-white border-t border-gray-200">
        <div className="flex items-center justify-between text-xs text-gray-400">
          <span>Agentic AI v1.0</span>
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span>Online</span>
          </div>
        </div>
      </div>
    </div>
  );
}
