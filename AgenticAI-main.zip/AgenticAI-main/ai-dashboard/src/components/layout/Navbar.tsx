"use client";

import { usePathname } from "next/navigation";
import { useAuthStore } from "@/lib/store/useAuthStore";
import { useAIPanelStore } from "@/lib/store/useAIPanelStore";
import { LogOut, User, Bot } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { cn } from "@/lib/utils/cn";

const PAGE_TITLES: Record<string, string> = {
  "/": "Overview",
  "/transactions": "Transactions",
  "/alerts": "Alerts",
  "/chat": "AI Chat",
};

export function Navbar() {
  const pathname = usePathname();
  const { user, logout } = useAuthStore();
  const { togglePanel, isOpen } = useAIPanelStore();

  const pageTitle = PAGE_TITLES[pathname] || "Overview";

  return (
    <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-gray-200">
      <div className="flex items-center justify-between px-6 py-4">
        {/* Left side - Dynamic Page title */}
        <div className="flex-1">
          <h1 className="text-xl font-semibold text-gray-900">
            {pageTitle}
          </h1>
        </div>

        {/* Right side - AI toggle + User menu */}
        <div className="flex items-center gap-3">
          {/* AI Panel Toggle */}
          <Button
            variant={isOpen ? "primary" : "ghost"}
            size="sm"
            onClick={togglePanel}
            className={cn(
              "gap-2",
              isOpen ? "bg-gray-900 text-white hover:bg-gray-800" : "text-gray-600"
            )}
          >
            <Bot className="w-4 h-4" />
            <span className="hidden sm:inline">AI Assistant</span>
          </Button>
          {/* User info */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
              {user?.avatar ? (
                <img
                  src={user.avatar}
                  alt={user.name || "User avatar"}
                  className="w-full h-full object-cover"
                />
              ) : (
                <User className="w-5 h-5 text-gray-500" />
              )}
            </div>
            <div className="hidden sm:block">
              <p className="text-sm font-medium text-gray-900">
                {user?.name || "User"}
              </p>
              <p className="text-xs text-gray-500">
                {user?.email}
              </p>
            </div>
          </div>

          {/* Logout button */}
          <Button
            variant="ghost"
            size="sm"
            onClick={logout}
            className="text-gray-500 hover:text-red-600 hover:bg-red-50"
            aria-label="Logout"
          >
            <LogOut className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </header>
  );
}
